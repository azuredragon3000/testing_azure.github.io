/* Simple LED task demo:
 *
 * The LED on PC13 is toggled in task1.
 */
#include "FreeRTOS.h"
#include "task.h"
#include "fun1.h"
#include <string.h>

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>

static int varStatic;
int globalVar = 10;
int globalVarBss;
int globalArr[100];
bool globalbool = true;

struct Distance1 dt1;
struct Distance2 dt2;

struct Distance1{
    char first;
    double feet;
    int inch;
};


struct Distance2{
    double feet;
    int inch;
    char last;
};

union DtUnion {
    int i;
    double f;
    //char str[20];
};

union DtUnion uuuu;

extern void vApplicationStackOverflowHook(xTaskHandle *pxTask,signed portCHAR *pcTaskName);

void
vApplicationStackOverflowHook(xTaskHandle *pxTask,signed portCHAR *pcTaskName) {
	(void)pxTask;
	(void)pcTaskName;
	for(;;);
}

static void
task1(void *args) {
	int i;

	(void)args;

	for (;;) {
		gpio_toggle(GPIOC,GPIO13);
		for (i = 0; i < 1000000; i++)
			__asm__("nop");
	}
}

int
main(void) {

	int i =0;
	rcc_clock_setup_in_hse_8mhz_out_72mhz();	// Use this for "blue pill"
	rcc_periph_clock_enable(RCC_GPIOC);
	gpio_set_mode(GPIOC,GPIO_MODE_OUTPUT_2_MHZ,GPIO_CNF_OUTPUT_PUSHPULL,GPIO13);

	for(i=0;i<100;i++)
	{
		globalArr[i] =1;
	}
	globalVar = funAdd(10,20);
	globalVarBss = funVar;
	varStatic =5;

	if(globalbool)
	{
		funcVoid();
	}

	dt1.first = 1;
	dt1.feet = 2;
	dt1.inch = 3;

	dt2.feet = 1;
	dt2.inch =3;
	dt2.last = 4;


	uuuu.i = 10;
	uuuu.f = 220.5;
	//strcpy(uuuu.str, "Hello, World!");

	xTaskCreate(task1,"LED",100,NULL,configMAX_PRIORITIES-1,NULL);
	vTaskStartScheduler();
	for (;;);

	return 0;
}

// End
