

int funAdd(int a,int b);
void funcVoid();

int funVar;
static int funcVarStatic = 10;

int funAdd(int a,int b){
	funcVarStatic++;
   return a+b+funcVarStatic;
}

void funcVoid(){
  int b=10;
  int c=20;
  c = c+b;
  funcVarStatic = c;
}
