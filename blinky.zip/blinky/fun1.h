



#ifndef FUNC_H
#define FUNC_H

extern funVar;
// Khai báo hàm funAdd
int funAdd(int a, int b);
void funcvoid();

#endif // FUNC_H

